#include "teaclib.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
 #define true 1
 #define false 0  

int limit,number,counter;

int prime(int n){
int i;
int result,isPrime;
if (n < 0){
result = prime(-n);

} 
 else if (n < 2){
result = false;

} 
 else if (n == 2){
result = true;

} 
 else if (n % 2 == 0){
result = false;

} 
 else{
i = 3;
isPrime = true;
 while(isPrime && (i < n / 2)){
isPrime = n % i != 0;
i = i + 2;
 
} 
result = isPrime;
   
} 
 
 
 
return result;
   
}
 int main(){
int array[5][5],i=0,j=0;
 while(i < 5){
 while(j < 5){
array[i][j] = 5;
j = j + 1;
 
} 
i = i + 1;
 
} 
limit = readInt();
counter = 0;
number = 2;
 while(number <= limit){
if (prime(number)){
counter = counter + 1;
writeInt(number);
writeString(" ");
  
} 
number = number + 1;
 
} 
writeString("\n");
writeInt(counter);
       
}

//Accepted!
