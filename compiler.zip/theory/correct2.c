#include "teaclib.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
 #define true 1
 #define false 0  

int N=100;
int a,b;

int cube(int i){
return i * i * i;

}
 int add(int n,int k){
int j;
j = (N - n) + cube(k);
writeInt(j);
return j;
   
}
 int main(){
a = readInt();
b = readInt();
add(a , b);
return 0;
   
}

//Accepted!
